#include <stdio.h>  // For printf
#include <stddef.h> // For NULL
#include "my_stack.h" // For your custom stack functions

int main() {
    struct node *top = NULL;
    printf("stack status: ");
    print(top);
    push(&top, 10);
    push(&top, 20);
    push(&top, 30);
    printf("stack values: ");
    print(top);
    int val1 = pop(&top);
    int val2 = pop(&top);
    printf("popped values: %d, %d\n", val1, val2);
    printf("stack values: ");
    print(top);
    int val3 = pop(&top);
    printf("popped value: %d\n", val3);
    printf("stack values: ");
    print(top);

    return 0;
}
