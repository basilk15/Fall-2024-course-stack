#include <stdio.h>
#include <stdlib.h>
#include "my_stack.h"

//pushing to top of stack
void push(struct node **top, int val) {
    struct node *n = malloc(sizeof(struct node));
    if (n == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }
    n->val=val;
    n->next=*top;
    *top=n;
}

//popping from the top of the stack
int pop(struct node **top) {
    if (top == NULL || *top==NULL) {
        fprintf(stderr, "stack is empty\n");
        exit(1);
    }
    struct node *n = *top;
    int val = n->val;
    *top = (*top)->next;
    free(n);
    return val;
}

//printing the stack
void print(struct node *top){
    if (top == NULL){
        printf("stack is empty\n");
    } else{
        while (top!= NULL) {
            printf("%d, ", top->val);
            top=top->next;
        }
        printf("\n");
    }
}
