#include <stdio.h>
#include "linked_list.h"

int main() {
    struct node *head = NULL;
    insert_at(&head, 0, 10);  
    insert_at(&head, 1, 20);  
    insert_at(&head, 2, 30);
    insert_at(&head, 1, 15);  
    printf("linked list value after insert: ");
    print(head);
    int removed_value = remove_at(&head, 2);
    printf("Removed value: %d\n", removed_value);    
    printf("Linked list after removal: ");
    print(head);

    return 0;
}
