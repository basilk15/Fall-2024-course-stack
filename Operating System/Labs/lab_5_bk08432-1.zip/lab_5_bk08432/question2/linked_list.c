#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

void insert_at(struct node **head, int index, int val) {
    struct node *new_node = malloc(sizeof(struct node));
    if (new_node == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        exit(1);
    }
    new_node->val = val;
    new_node->next = NULL;
    if (index == 0) {
        new_node->next = *head;
        *head = new_node;
        return;
    }
    struct node *current = *head;
    for (int i = 0; i < index - 1; i++) {
        if (current == NULL) {
            fprintf(stderr, "Index out of bounds\n");
            free(new_node);
            return;
        }
        current = current->next;
    }
    new_node->next = current->next;
    current->next = new_node;
}
int remove_at(struct node **head, int index) {
    if (*head == NULL) {
        fprintf(stderr, "List is empty\n");
        exit(1);
    }
    struct node *temp;
    int val;
    if (index==0){
        temp = *head;
        *head = (*head)->next;
        val = temp->val;
        free(temp);
        return val;
    }
    struct node *current = *head;
    for (int i = 0; i < index - 1; i++) {
        if (current == NULL || current->next == NULL) {
            fprintf(stderr, "Index out of bounds\n");
            exit(1);
        }
        current = current->next;
    }
    temp = current->next;
    current->next = temp->next;
    val = temp->val;
    free(temp);
    return val;
}

void print(struct node *head) {
    while (head != NULL) {
        printf("%d -> ", head->val);
        head = head->next;
    }
    printf("NULL\n");
}
