#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <pthread.h>
#include <time.h>

#define INC_SIZE 10000000

volatile int glob = 0; 
void *increment_global(void *arg) {
    for (int i = 0; i < INC_SIZE; i++) {
        glob++;  
    }
    return NULL;
}

int main() {
    pthread_t t1, t2; 
    struct timespec start, end; 
    double elapsed_time;
    clock_gettime(CLOCK_MONOTONIC, &start);
    pthread_create(&t1, NULL, increment_global, NULL);
    pthread_create(&t2, NULL, increment_global, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    clock_gettime(CLOCK_MONOTONIC, &end);
    elapsed_time = (end.tv_sec - start.tv_sec) + 
                   (end.tv_nsec - start.tv_nsec) / 1000000000.0;

    printf("Final value of glob (no mutex): %d\n", glob);
    printf("Time taken (no mutex): %f seconds\n", elapsed_time);

    return 0;
}
