#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

struct Node {
    int data;
    struct Node *next;
};

struct Node *head = NULL;
pthread_mutex_t list_mutex = PTHREAD_MUTEX_INITIALIZER;

void add(int value) {
    pthread_mutex_lock(&list_mutex);
    struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
    temp->data = value;
    temp->next = head;
    head = temp;
    pthread_mutex_unlock(&list_mutex);
}

void remove_first(int value) {
    pthread_mutex_lock(&list_mutex);
    struct Node *curr = head, *prev = NULL;

    while (curr && curr->data != value) {
        prev = curr;
        curr = curr->next;
    }

    if (curr) {
        if (prev) {
            prev->next = curr->next;
        } else {
            head = curr->next;
        }
        free(curr);
    }
    pthread_mutex_unlock(&list_mutex);
}

int search(int value) {
    pthread_mutex_lock(&list_mutex);
    struct Node *curr = head;

    while (curr) {
        if (curr->data == value) {
            pthread_mutex_unlock(&list_mutex);
            return 1; 
        }
        curr = curr->next;
    }
    pthread_mutex_unlock(&list_mutex);
    return 0; 
}

int size() {
    pthread_mutex_lock(&list_mutex);
    int count = 0;
    struct Node *curr = head;

    while (curr) {
        count++;
        curr = curr->next;
    }
    pthread_mutex_unlock(&list_mutex);
    return count;
}

void *add_to_list(void *arg) {
    int base = *(int *)arg;
    for (int i = base; i < base + 50000; i++) {
        add(i);
    }
    return NULL;
}

void *delete_from_list(void *arg) {
    int base = *(int *)arg;
    for (int i = base; i < base + 1000; i++) {
        remove_first(i);
    }
    return NULL;
}

int main() {
    pthread_t t1, t2, t3, t4;
    int start1 = 1, start2 = 50001, start3 = 1, start4 = 50001;

    pthread_create(&t1, NULL, add_to_list
, &start1);
    pthread_create(&t2, NULL, add_to_list
, &start2);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    pthread_create(&t3, NULL, delete_from_list, &start3);
    pthread_create(&t4, NULL, delete_from_list, &start4);

    pthread_join(t3, NULL);
    pthread_join(t4, NULL);

    printf("Total elements: %d\n", size());
    printf("Search for 49999: %s\n", search(49999) ? "Found" : "Not Found");
    printf("Search for 100000: %s\n", search(100000) ? "Found" : "Not Found");

    pthread_mutex_destroy(&list_mutex);
    return 0;
}
