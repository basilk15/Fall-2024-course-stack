#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *next;
};

struct Node *head = NULL;

void add(int value) {
    struct Node *temp = (struct Node *)malloc(sizeof(struct Node));
    temp->data = value;
    temp->next = head;
    head = temp;
}

void remove_first(int value) {
    struct Node *curr = head, *prev = NULL;

    while (curr && curr->data != value) {
        prev = curr;
        curr = curr->next;
    }

    if (curr) {
        if (prev) {
            prev->next = curr->next;
        } else {
            head = curr->next;
        }
        free(curr);
    }
}

int search(int value) {
    struct Node *curr = head;

    while (curr) {
        if (curr->data == value) {
            return 1; // Element found
        }
        curr = curr->next;
    }
    return 0; // Element not found
}

int size() {
    int count = 0;
    struct Node *curr = head;

    while (curr) {
        count++;
        curr = curr->next;
    }
    return count;
}

int main() {
    for (int i = 0; i < 100000; i++) {
        add(i);
    }

    for (int i = 0; i < 1000; i++) {
        remove_first(i);
    }

    printf("Total elements: %d\n", size());
    printf("Search for 999: %s\n", search(999) ? "Found" : "Not Found");
    printf("Search for 100001: %s\n", search(100001) ? "Found" : "Not Found");

    return 0;
}
