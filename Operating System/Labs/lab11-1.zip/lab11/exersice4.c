#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h> // For getpid() and sleep()

void *print_message(void *args) {
    char *message = (char *)args;
    printf("%s TID: %lu, PID: %d\n", message, pthread_self(), getpid());
    return NULL;
}

void *input_name_message(void *args) {
    char name[50];
    printf("Please enter your name: ");
    scanf("%49s", name); // Capture user's input
    printf("Hello, %s! TID: %lu, PID: %d\n", name, pthread_self(), getpid());
    return NULL;
}

void *input_age_message(void *args) {
    int age;
    printf("Please enter your age: ");
    scanf("%d", &age);
    printf("You are %d years old! TID: %lu, PID: %d\n", age, pthread_self(), getpid());
    return NULL;
}

int main(int argc, char *argv[]) {
    pthread_t t1, t2, t3, t4, t5;
    char message1[] = "Thread 1: Hello from thread 1!";
    char message2[] = "Thread 2: This is thread 2 speaking!";
    char message3[] = "Thread 3: Greetings from thread 3!";

    pthread_create(&t1, NULL, print_message, message1);
    pthread_create(&t2, NULL, print_message, message2);
    pthread_create(&t3, NULL, print_message, message3);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);

    pthread_create(&t4, NULL, input_name_message, NULL);
    pthread_join(t4, NULL);

    pthread_create(&t5, NULL, input_age_message, NULL);
    pthread_join(t5, NULL);

    printf("End of the program.\n");
    return 0;
}
