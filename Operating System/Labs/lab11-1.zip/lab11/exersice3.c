#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>   // For getpid()

void *hello_fun(void *args) {
    printf("Hello, world! TID: %lu, PID: %d\n", pthread_self(), getpid());
    return NULL;
}

void *my_name(void *args) {
    printf("Hello, my name is Basil, what's up? TID: %lu, PID: %d\n", pthread_self(), getpid());
    return NULL;
}

void *input_name(void *args) {
    char name[50];
    printf("Please enter your name: ");
    scanf("%s", name);
    printf("Nice to meet you, %s! TID: %lu, PID: %d\n", name, pthread_self(), getpid());
    return NULL;
}

void *calculate_sum(void *args) {
    int a = 5, b = 10;
    int sum = a + b;
    printf("Sum of %d and %d is %d. TID: %lu, PID: %d\n", a, b, sum, pthread_self(), getpid());
    return NULL;
}

int main(int argc, char *argv[]) {
    pthread_t t0, t1, t2, t3, t4;
    pthread_create(&t0, NULL, hello_fun, NULL);
    pthread_create(&t1, NULL, hello_fun, NULL);
    pthread_create(&t2, NULL, my_name, NULL);
    pthread_create(&t3, NULL, input_name, NULL);
    pthread_create(&t4, NULL, calculate_sum, NULL);
    pthread_join(t0, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    pthread_join(t3, NULL);
    pthread_join(t4, NULL);

    printf("End of the program.\n");
    return 0;
}
