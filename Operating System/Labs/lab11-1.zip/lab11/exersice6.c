#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
long long counter = 0;
void *increment_counter(void *args) {
    for (int i = 0; i < 2500000; i++) { 
        counter++; 
    }
    return NULL;
}

void *input_name(void *args) {
    char name[50];
    printf("Please enter your name: ");
    scanf("%49s", name);
    printf("Hello, %s!\n", name);
    return NULL;
}

void *input_age(void *args) {
    int age;
    printf("Please enter your age: ");
    scanf("%d", &age);
    printf("You are %d years old!\n", age);
    return NULL;
}

int main() {
    pthread_t name_thread, age_thread;
    pthread_t threads[4];
    pthread_create(&name_thread, NULL, input_name, NULL);
    pthread_join(name_thread, NULL); 

    pthread_create(&age_thread, NULL, input_age, NULL);
    pthread_join(age_thread, NULL); 

    for (int i = 0; i < 4; i++) {
        pthread_create(&threads[i], NULL, increment_counter, NULL);
    }

    for (int i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("Final value of counter: %lld\n", counter);

    return 0;
}
