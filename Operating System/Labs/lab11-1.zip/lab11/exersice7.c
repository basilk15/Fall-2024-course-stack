#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>

void *input_name(void *args) {
    char name[50];
    printf("Please enter your name: ");
    scanf("%49s", name);
    printf("Hello, %s! TID: %lu\n", name, pthread_self());
    pthread_exit(NULL);
}

void *input_age(void *args) {
    int age;
    printf("Please enter your age: ");
    scanf("%d", &age);
    printf("You are %d years old! TID: %lu\n", age, pthread_self());
    pthread_exit(NULL);
}

void *input_hobby(void *args) {
    char hobby[50];
    printf("Please enter your hobby: ");
    scanf("%49s", hobby);
    printf("Your hobby is %s. TID: %lu\n", hobby, pthread_self());
    pthread_exit(NULL);
}

void *removed(void *args) {
    printf("for removed thread. TID: %lu\n", pthread_self());
    pthread_exit(NULL);
}

int main() {
    pthread_t name_thread, age_thread, hobby_thread, det_thread;
    pthread_create(&name_thread, NULL, input_name, NULL);
    pthread_join(name_thread, NULL); 
    pthread_create(&age_thread, NULL, input_age, NULL);
    pthread_join(age_thread, NULL); 
    pthread_create(&hobby_thread, NULL, input_hobby, NULL);
    pthread_join(hobby_thread, NULL); 
    pthread_create(&det_thread, NULL, removed, NULL);
    pthread_detach(det_thread);
    if (pthread_equal(name_thread, age_thread)) {
        printf("Name thread and age thread are the same.\n");
    } else {
        printf("Name thread and age thread are different.\n");
    }
    printf("Main thread is done. TID: %lu\n", pthread_self());

    pthread_exit(NULL); 
    return 0;
}
