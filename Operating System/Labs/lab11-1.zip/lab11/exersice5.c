#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

void *enter_name(void *args) {
    char name[50];
    printf("Please enter your name: ");
    scanf("%49s", name);
    printf("Hello, %s! TID: %lu\n", name, pthread_self());
    pthread_exit(NULL); 
}

void *enter_age(void *args) {
    int age;
    printf("Please enter your age: ");
    scanf("%d", &age);
    printf("You are %d years old! TID: %lu\n", age, pthread_self());
    pthread_exit(NULL); 
}

void *exit_example(void *args) {
    printf("Thread with exit() is running. TID: %lu\n", pthread_self());
    exit(0); 
}

int main() {
    pthread_t t1, t2, t3;
    pthread_create(&t1, NULL, enter_name, NULL);
    pthread_join(t1, NULL);
    pthread_create(&t2, NULL, enter_age, NULL);
    pthread_join(t2, NULL);
    pthread_create(&t3, NULL, exit_example, NULL);
    pthread_join(t3, NULL); 

    printf("this will not print if exit() is called by any thread.\n");

    return 0;
}
