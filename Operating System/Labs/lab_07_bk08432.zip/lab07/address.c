#include <stdio.h>

void guess(){
    int x=5;
    int y=10;
    int *pointer_x=&x;
    int *pointer_y=pointer_x+4;

    printf("start value: x=%d, y=%d\n",x,y);
    printf("address of x: %p\n", (void*)pointer_x);
    printf("guessed address of y: %p\n", (void*)pointer_y);

    *pointer_y=100;

    printf("after changing the values are: x = %d, y = %d\n", x, y);
}

int main() {
    guess();
    return 0;
}
