#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

int main() {
    int num = 1024;
    size_t size = num * sizeof(int);
    int *mapped_mem = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
    if (mapped_mem == MAP_FAILED) {
        perror("mmap");
        exit(EXIT_FAILURE);
    }
    printf("memory successfully allocated at address: %p\n", mapped_mem);
    for (int i = 0; i < num; i++) {
        mapped_mem[i] = i * 2;
    }
    for (int i = 0; i < num; i++) {
        if (mapped_mem[i] != i * 2) {
            printf("value at index %d is incorrect! Expected %d but got %d\n", i, i * 2, mapped_mem[i]);
            munmap(mapped_mem, size);
            exit(EXIT_FAILURE);
        }
    }
    printf("All values verified successfully.\n");
    if (munmap(mapped_mem, size) == -1) {
        perror("munmap");
        exit(EXIT_FAILURE);
    }

    return 0;
}
