#include <stdio.h>

void corrupt_function(){
    char buffer[16];
    printf("Buffer address: %p\n", buffer);
    for (int i = 0; i < 32; i++) {
        buffer[i] = 'A'; 
    }
    printf("Return address corrupted!\n");
}

int main() {
    corrupt_function();
    printf("This will never be printed if return address is corrupted.\n");
    return 0;
}

