#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>     // For open(), O_CREAT, O_WRONLY
#include <sys/wait.h>
#include <string.h>

#define MAX_LEN 256   // Maximum command length
#define MAX_ARGS 10   // Maximum number of arguments

int main(){
    char command[MAX_LEN];  // Buffer to store the command entered by the user
    char *args[MAX_ARGS];   // Array to store the arguments
    int status;
    while (1){
        printf("prompt> ");
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = '\0';
        if(strcmp(command, "exit")==0){
            break;
        }
        char *output_file=NULL;
        char *redirect=strchr(command,'>');
        if (redirect!=NULL){
            *redirect='\0';
            output_file=strtok(redirect + 1, " ");
        }
        int i=0;
        args[i]=strtok(command, " ");
        while (args[i]!=NULL && i<MAX_ARGS-1){
            i=i+1;
            args[i]=strtok(NULL, " ");
        }
        args[i]=NULL;
        int rc=fork();
        if (rc<0){
            fprintf(stderr, "fork failed\n");
            exit(1);
        } else if (rc==0){
            if (output_file!=NULL){
                int fd=open(output_file, O_CREAT | O_WRONLY | O_TRUNC, S_IRWXU);
                if (fd<0){
                    fprintf(stderr, "eerror in opening file %s\n", output_file);
                    exit(1);}
                dup2(fd, STDOUT_FILENO);
                close(fd);
            }
            execvp(args[0], args);
            fprintf(stderr, "Error executing command\n");
            exit(1);
        } else {
            wait(&status);
        }
    }

    return 0;
}
