#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

#define MAX_ARGS 10
#define MAX_LEN 256

int main() {
    char command[MAX_LEN];
    char *args[MAX_ARGS];
    int status;
    while (1){
        printf("prompt> ");
        fgets(command, sizeof(command), stdin);
        command[strcspn(command, "\n")] = '\0';
        if (strcmp(command, "exit")==0){
            break; 
        }
        int i=0;
        args[i]=strtok(command, " ");
        while (args[i]!=NULL && i<MAX_ARGS-1){
            i=i+1;
            args[i]=strtok(NULL, " ");
        }
        args[i]=NULL;
        int rc=fork();  //forking like in q1
        if (rc<0){
            fprintf(stderr, "fork fail\n");
            exit(1);
        }else if(rc==0){
            execvp(args[0],args);
            fprintf(stderr, "error in running the given command\n");
            exit(1);
        } else{
            wait(&status);
        }
    }

    return 0;
}
