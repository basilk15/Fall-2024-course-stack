#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    printf("hello world (pid:%d)\n", (int) getpid());
    int rc = fork();
    if (rc < 0) {
        fprintf(stderr, "fork failed\n");
        exit(1);
    } else if (rc==0){
        sleep(10);  //sleeps for 1 second
        printf("hello, I am child (pid:%d)\n", (int) getpid());
	system("ps -f"); //to show current process during the execution of program itself
    } else {
        sleep(10);
        printf("hello, I am parent of %d (pid:%d)\n", rc, (int) getpid());
	system("ps -f");
    }
    return 0;
}
