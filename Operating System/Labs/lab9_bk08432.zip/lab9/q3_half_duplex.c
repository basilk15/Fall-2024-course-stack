#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h> 
int main() {
    int fd;
    char *fifo = "/tmp/myfifo";
    char message[100];
    pid_t pid;
    mkfifo(fifo, 0666);
    pid=fork();
    if (pid > 0) {
        while (1) {
            fd = open(fifo, O_WRONLY);
            printf("P1: Enter message: ");
            fgets(message, 100, stdin);
            write(fd, message, strlen(message) + 1);
            close(fd);
        }
    } else { //p2 reciever
        while (1) {
            fd = open(fifo, O_RDONLY);
            read(fd, message, sizeof(message));
            printf("P2 received: %s\n", message);
            close(fd);
        }
    }

    return 0;
}
