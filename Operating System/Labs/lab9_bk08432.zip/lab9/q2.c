#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>

int main() {
    int fd;
    pid_t process_id;
    char buffer_array[100];
    char message[] = "message from writer";
    mkfifo("/tmp/myfifo", 0666);
    for (int i=1; i<=3; i++) {
        process_id=fork();
        if (process_id==0) {  
            fd=open("/tmp/myfifo", O_RDONLY); 
            read(fd, buffer_array, sizeof(buffer_array));  
            printf("reader %d received: %s\n", i, buffer_array);  
            close(fd);  
            exit(0);
        }
    }
    sleep(2);
    fd=open("/tmp/myfifo", O_WRONLY); 
    for (int i=1; i<=3; i++) {
        write(fd, message, sizeof(message));  
        fsync(fd); 
        sleep(1);  }
    close(fd);  
    for (int i=0; i<3; i++) {
        wait(NULL);  
    }

    return 0;
}
