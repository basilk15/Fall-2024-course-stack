#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int pipeFileDescriptors[2];
    int processID;
    char message[20];
    pipe(pipeFileDescriptors);
    processID = fork();
    if (processID > 0) {
        printf("waiting for the child to send message\n");
        wait(NULL);
        read(pipeFileDescriptors[0], message, sizeof(message));
        printf("parent received: %s\n", message);
    } else if (processID==0){
        printf("sending a message to the parent\n");
        char childMessage[] = "Hi Parent, from Child";
        write(pipeFileDescriptors[1], childMessage, sizeof(childMessage));
    } else {
        printf("error\n");
    }

    return 0;
}
