#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h> 
int main() {
    int fd1, fd2;
    char *fifo1 = "/tmp/fifo1";  
    char *fifo2 = "/tmp/fifo2"; 
    char message[100];
    pid_t pid;
    mkfifo(fifo1, 0666);
    mkfifo(fifo2, 0666);
    pid = fork();
    if (pid > 0) { 
        while (1) {
            fd1 = open(fifo1, O_WRONLY);
            printf("P1: Enter message: ");
            fgets(message, 100, stdin);
            write(fd1, message, strlen(message) + 1);
            close(fd1);
            fd2 = open(fifo2, O_RDONLY);
            read(fd2, message, sizeof(message));
            printf("P1 received: %s\n", message);
            close(fd2);
        }
    } else { 
        while (1) {
            fd1 = open(fifo1, O_RDONLY);
            read(fd1, message, sizeof(message));
            printf("P2 received: %s\n", message);
            close(fd1);
            fd2 = open(fifo2, O_WRONLY);
            printf("P2: Enter message: ");
            fgets(message, 100, stdin);
            write(fd2, message, strlen(message) + 1);
            close(fd2);
        }
    }

    return 0;
}
