#include <stdio.h>
#include <stdlib.h>
#include "my_stack.h"

void push(struct node **top, int val) {
    struct node *n = malloc(sizeof(struct node));
    if (n == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return;
    }
    n->val = val;
    n->next = *top;
    *top = n;
}

int pop(struct node **top) {
    if (*top == NULL) {
        fprintf(stderr, "Stack underflow\n");
        return -1; 
    }
    int val = (*top)->val;
    struct node *temp = *top;
    *top = (*top)->next;
    free(temp);
    return val;
}
void print(struct node *top) {
    struct node *current = top;
    while (current != NULL) {
        printf("%d ", current->val);
        current = current->next;
    }
    printf("\n");
}
