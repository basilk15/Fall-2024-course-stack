// my_stack.h
#ifndef MY_STACK_H
#define MY_STACK_H
struct node {
    int val;
    struct node *next;
};
void push(struct node **top, int val);
int pop(struct node **top);
void print(struct node *top);
#endif
