#ifndef LINKED_LIST_H
#define LINKED_LIST_H

struct node {
    int val;
    struct node *next;
};

void insert_at(struct node **head, int index, int val);
int remove_at(struct node **head, int index);
void print(struct node *head);

#endif
