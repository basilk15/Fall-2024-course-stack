#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>

#define BUFFER_SIZE 10

int buffer[BUFFER_SIZE];
int in = 0;
int out = 0;
int count = 0;

pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_producer = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_consumer = PTHREAD_COND_INITIALIZER;

void* producer(void* arg) {
    int numItemsToProduce = atoi((char*)arg);
    for (int i = 0; i < numItemsToProduce; i++) {
        pthread_mutex_lock(&mtx);
        while (count == BUFFER_SIZE) {
            pthread_cond_wait(&cond_producer, &mtx);
        }
        int item = rand() % 100;
        buffer[in] = item;
        printf("produced %d at index %d\n", item, in);
        in = (in + 1) % BUFFER_SIZE;
        count++;
        pthread_cond_signal(&cond_consumer);
        pthread_mutex_unlock(&mtx);
    }
    return NULL;
}

void* consume(void* arg) {
    int numitems = atoi((char*)arg);
    for (int i = 0; i < numitems; i++) {
        pthread_mutex_lock(&mtx);
        while (count == 0) {
            pthread_cond_wait(&cond_consumer, &mtx);
        }
        int item = buffer[out];
        printf("used %d from index %d\n", item, out);
        out = (out + 1) % BUFFER_SIZE;
        count--;
        pthread_cond_signal(&cond_producer);
        pthread_mutex_unlock(&mtx);
    }
    return NULL;
}

int main(int argc, char* argv[]) {
    pthread_t tidProducer, tidConsumer;

    if (argc < 3) {
        printf("Usage: %s <numProducerItems> <numConsumerItems>\n", argv[0]);
        return 1;
    }

    srand(time(NULL));
    pthread_create(&tidProducer, NULL, producer, argv[1]);
    pthread_create(&tidConsumer, NULL, consume, argv[2]);
    pthread_join(tidProducer, NULL);
    pthread_join(tidConsumer, NULL);

    printf("end of code\n");

    return 0;
}
