#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    char name[100];
    pid_t parent_pid = getppid(); 
    
    printf("Enter your name: ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = 0;  
    
    printf("Sending signal to parent process (PID: %d)\n", parent_pid);
    
    if (kill(parent_pid, SIGUSR1) == -1) {
        perror("Failed to send SIGUSR1 signal");
        return 1;
    }
    
    printf("Hello %s, successfully sent SIGUSR1 signal to parent process %d\n", 
           name, parent_pid);
    return 0;
}
