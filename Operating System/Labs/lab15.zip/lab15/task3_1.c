#define _POSIX_C_SOURCE 199309L
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

void do_work(const char* state) {
    printf("Working while SIGINT is %s\n", state);
    sleep(3);
}

int main() {
    sigset_t newsigset, oldsigset;
    
    if (sigemptyset(&newsigset) == -1) {
        perror("Failed to initialize signal set");
        return 1;
    }
    
    if (sigaddset(&newsigset, SIGINT) == -1) {
        perror("Failed to add SIGINT to signal set");
        return 1;
    }
    
    printf("Try pressing Ctrl-C at different times\n");
    
    while(1) {
        if (sigprocmask(SIG_BLOCK, &newsigset, &oldsigset) == -1) {
            perror("Failed to block SIGINT");
            return 1;
        }
        do_work("blocked");
        if (sigprocmask(SIG_UNBLOCK, &newsigset, NULL) == -1) {
            perror("Failed to unblock SIGINT");
            return 1;
        }
        do_work("unblocked");
    }
    
    return 0;
}
