#define _POSIX_C_SOURCE 199309L
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    sigset_t blockmask;
    pid_t pid;
    if (sigfillset(&blockmask) == -1) {
        perror("Failed to initialize signal mask");
        return 1;
    }

    if (sigprocmask(SIG_SETMASK, &blockmask, NULL) == -1) {
        perror("Failed to block signals");
        return 1;
    }
    
    pid = fork();
    
    if (pid == -1) {
        perror("Fork failed");
        return 1;
    }
    
    if (pid == 0) { 
        execl("/bin/ls", "ls", NULL);
        perror("Exec failed");  
        return 1;
    }
    
    wait(NULL);
    return 0;
}
